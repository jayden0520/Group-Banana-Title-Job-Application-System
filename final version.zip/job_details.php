<?php
session_start();
require 'db_connect.php'; 

// id/job_id
if (isset($_GET['job_id'])) {
    $id = intval($_GET['job_id']);
} elseif (isset($_GET['id'])) {
    $id = intval($_GET['id']);
} else {
    header("Location: index.php");
    exit();
}

$sql = "SELECT j.*, c.category_name 
        FROM jobs j 
        LEFT JOIN job_categories c ON j.category_id = c.category_id 
        WHERE j.job_id = $id";

$result = mysqli_query($conn, $sql);
$job = mysqli_fetch_assoc($result);

if (!$job) {
    die("Job not found.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo $job['title']; ?> - Details</title>
    <link rel="stylesheet" href="system.css">
</head>

<body>

    <nav>
        <div class="container">
            <h1>JobSeeker</h1>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about_us.php">About Us</a></li>
                <li><a href="faq.php">FAQ</a></li> <?php if (isset($_SESSION['user_id'])): ?>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="dashboard.php?logout=true" style="color: #ff6b6b;">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <div class="form-container" style="max-width: 800px; margin-top: 40px;">

        <h2 style="color: #2c3e50; font-size: 2em;"><?php echo $job['title']; ?></h2>
        
        <p style="color: #7f8c8d;">
            <span style="background: #e1f5fe; padding: 5px 10px; border-radius: 4px; color: #0277bd;">
                <?php echo $job['category_name']; ?>
            </span>
            &nbsp; | &nbsp; 
            📍 <?php echo $job['location']; ?>
            &nbsp; | &nbsp; 
            💰 <b><?php echo $job['salary']; ?></b>
        </p>

        <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">

        <h3>Job Description</h3>
        <p style="line-height: 1.6; color: #333;">
            <?php echo nl2br($job['description']); ?>
        </p>

        <br><br>
        
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="apply.php?job_id=<?php echo $job['job_id']; ?>" class="btn" style="display:inline-block; text-align:center; padding: 12px 30px;">Apply Now</a>
        <?php else: ?>
            <a href="login.php" class="btn" style="background-color: #7f8c8d;">Login to Apply</a>
        <?php endif; ?>
        
        <a href="index.php" class="btn" style="background-color: transparent; color: #555; border: 1px solid #ccc; margin-left: 10px;">Back</a>

    </div>

</body>
</html>