<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Confirmation</title>
    <link rel="stylesheet" href="system.css">
</head>
<body>

    <nav>
        <div class="container">
            <h1>JobSeeker</h1>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about_us.php">About Us</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
            </ul>
        </div>
    </nav>

    <div class="form-container" style="text-align: center; margin-top: 100px;">
        <h2 style="color: #27ae60;">✔ Application Submitted!</h2>
        <p>Your job application has been successfully recorded.</p>
        <br>
        <a href="index.php" class="btn">Back to Job Listings</a>
        <a href="dashboard.php" class="btn" style="background-color: #555;">Go to Dashboard</a>
    </div>

</body>
</html>