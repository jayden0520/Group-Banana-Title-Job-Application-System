<?php
session_start();
require 'db_connect.php'; 

// Security Check: If user is not logged in OR if they accessed this page without a job_id
// Redirect them back to the index page.
if (!isset($_SESSION['user_id']) || !isset($_GET['job_id'])) {
    header("Location: index.php");
    exit();
}

$job_id = $_GET['job_id'];

$sql_job = "SELECT title FROM jobs WHERE job_id = $job_id";
$result_job = mysqli_query($conn, $sql_job);

if ($row = mysqli_fetch_assoc($result_job)) {
    $job_title = $row['title'];
} else {
    die("Job not found.");
}

// Handle form submission
if (isset($_POST['submit'])) {
    // Get the user ID from the session (this maps to 'applicant_id' in the database)
    $applicant_id = $_SESSION['user_id']; 
    
    // Table name: job_applications
    // Columns: applicant_id, job_id, status
    // Note: Since the database does not have a 'cover_letter' column, we only save the application record.
    $insert_query = "INSERT INTO job_applications (applicant_id, job_id, status) 
                     VALUES ('$applicant_id', '$job_id', 'Pending')";
    
    if (mysqli_query($conn, $insert_query)) {
        // Redirect to confirmation page upon success
        header("Location: confirmation.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Apply for <?php echo $job_title; ?></title>
    <link rel="stylesheet" href="system.css">
    <script src="job.js"></script>
</head>
<body>

    <nav>
        <div class="container">
            <h1>JobSeeker</h1>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about_us.php">About Us</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
            </ul>
        </div>
    </nav>

    <div class="form-container" style="width: 600px;">
        <h2 style="text-align: center;">Apply for <span style="color:#3498db;"><?php echo $job_title; ?></span></h2>

        <form method="post" onsubmit="return validateApplyForm()">
            <div class="form-group">
                <label>Applicant Name</label>
                <input type="text" value="<?php echo $_SESSION['fullname']; ?>" disabled style="background:#eee;">
            </div>

            <div class="form-group">
                <label>Cover Letter</label>
                <textarea name="cover" id="cover" rows="5" style="width:100%; padding:10px;" placeholder="Write a short message to the recruiter..."></textarea>
            </div>
            
            <button class="btn" name="submit" style="width:100%;">Submit Application</button>
        </form>
    </div>

</body>
</html>