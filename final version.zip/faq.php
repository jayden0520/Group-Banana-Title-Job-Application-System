<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <title>FAQ - JobSeeker</title>
    <link rel="stylesheet" href="system.css">
    <style>
        .faq-item { margin-bottom: 20px; }
        .faq-question { font-weight: bold; color: #2c3e50; font-size: 1.1em; }
        .faq-answer { color: #555; margin-top: 5px; }
    </style>
</head>

<body>

    <nav>
        <div class="container">
            <h1>JobSeeker</h1>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about_us.php">About Us</a></li>
                <li><a href="faq.php">FAQ</a></li>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="dashboard.php?logout=true" style="color: #ff6b6b;">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Sign Up</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <div class="form-container" style="max-width: 800px;">

        <h2 style="text-align: center; margin-bottom: 30px;">Frequently Asked Questions</h2>

        <div class="faq-item">
            <div class="faq-question">Q: How do I apply for a job?</div>
            <div class="faq-answer">A: Simply browse the job list on the Home page, click on a job card to view details, and click the "Apply Now" button. You need to be logged in.</div>
        </div>

        <div class="faq-item">
            <div class="faq-question">Q: Can I edit my application after submitting?</div>
            <div class="faq-answer">A: Currently, applications cannot be edited once submitted. Please contact the admin if you made a mistake.</div>
        </div>

        <div class="faq-item">
            <div class="faq-question">Q: How long does the process take?</div>
            <div class="faq-answer">A: Employers typically review applications within 3–5 working days. Check your Dashboard for status updates.</div>
        </div>
        
        <div class="faq-item">
            <div class="faq-question">Q: Is this service free?</div>
            <div class="faq-answer">A: Yes, JobSeeker is completely free for all candidates.</div>
        </div>

    </div>

</body>
</html>