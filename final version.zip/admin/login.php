<?php
require_once 'includes/config.php';

$error = "";

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = md5($_POST['password']);

    if (empty($username) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {
        $query = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) == 1) {
            $_SESSION['admin'] = $username;
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid username or password.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <style>
        /* Simple internal CSS */
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
        }
        .login-box {
            width: 350px;
            margin: 100px auto;
            padding: 20px;
            background: white;
            border-radius: 5px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
        }
        button {
            width: 100%;
            padding: 10px;
            background: #0d6efd;
            color: white;
            border: none;
        }
        .error {
            color: red;
        }
    </style>

    <script>
        function validateForm() {
            let u = document.forms["loginForm"]["username"].value;
            let p = document.forms["loginForm"]["password"].value;
            if (u === "" || p === "") {
                alert("All fields are required");
                return false;
            }
            return true;
        }
    </script>
</head>

<body>
    <img src="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YWRtaW58ZW58MHx8MHx8fDA%3D&w=1000&q=80" alt="Admin Login" style="width:100%; height:300px; object-fit:cover;">

<div class="login-box">
    <h2>Admin Login</h2>

    <?php if ($error) echo "<p class='error'>$error</p>"; ?>

    <form name="loginForm" method="POST" onsubmit="return validateForm();">
        <input type="text" name="username" placeholder="Username">
        <input type="password" name="password" placeholder="Password">
        <button type="submit" name="login">Login</button>
    </form>
</div>

</body>
</html>