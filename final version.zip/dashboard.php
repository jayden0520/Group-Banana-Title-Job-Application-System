<?php
session_start();
require 'db_connect.php'; 

// if user is not logged in, redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// logout handling
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; 

// connect job_application database
$sql_count = "SELECT COUNT(*) as total FROM job_applications WHERE applicant_id = '$user_id'";
$result_count = mysqli_query($conn, $sql_count);
$row_count = mysqli_fetch_assoc($result_count);
$total_applications = $row_count['total'];

// connect to fetch recent applications
$sql_recent = "SELECT ja.*, j.title, j.location, j.salary 
               FROM job_applications ja 
               JOIN jobs j ON ja.job_id = j.job_id 
               WHERE ja.applicant_id = '$user_id' 
               ORDER BY ja.applied_at DESC";
$result_recent = mysqli_query($conn, $sql_recent);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="system.css">
    <style>
        .dashboard-wrapper {
            display: block !important;
            width: 90%;
            max-width: 1000px;
            margin: 40px auto;
        }
        .main-content {
            width: 100% !important;
            flex: none !important;
        }
    </style>
</head>
<body>

    <nav>
        <div class="container">
            <h1>JobSeeker</h1>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about_us.php">About Us</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="dashboard.php?logout=true" style="color: #ff6b6b;">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="dashboard-wrapper">
        
        <div style="background: #e3f2fd; padding: 25px; border-radius: 8px; margin-bottom: 25px; border-left: 5px solid #2196f3;">
            <h2 style="margin-top:0;">Welcome back, <?php echo $_SESSION['fullname']; ?>!</h2>
            <p style="margin-bottom:0; color: #555;">Here is your latest application status.</p>
        </div>

        <div class="stats-grid">
            <div class="card">
                <h3><?php echo $total_applications; ?></h3>
                <p>Applications Sent</p>
            </div>
            <div class="card">
                <h3>0</h3> 
                <p>Interviews</p>
            </div>
        </div>

        <div class="table-container">
            <h3>My Application History</h3>
            
            <?php if (mysqli_num_rows($result_recent) > 0): ?>
                <table class="styled-table">
                    <thead>
                        <tr>
                            <th>Job Title</th>
                            <th>Location</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = mysqli_fetch_assoc($result_recent)): ?>
                            <tr>
                                <td><strong><?php echo $row['title']; ?></strong></td>
                                <td><?php echo $row['location']; ?></td>
                                <td>
                                    <?php 
                                        $status = $row['status'];
                                        $color = '#f39c12'; // Pending (Orange)
                                        if($status == 'Approved') $color = '#27ae60'; // Green
                                        if($status == 'Rejected') $color = '#c0392b'; // Red
                                    ?>
                                    <span class="badge" style="background-color: <?php echo $color; ?>;">
                                        <?php echo $status; ?>
                                    </span>
                                </td>
                                <td><?php echo date('Y-m-d', strtotime($row['applied_at'])); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 30px; background: #fafafa; border-radius: 8px;">
                    <p>No applications found yet.</p>
                    <a href="index.php" class="btn">Go Apply for Jobs</a>
                </div>
            <?php endif; ?>
        </div>

    </div>

</body>
</html>